# 🐙 دليل إعداد GitHub و GitHub Actions

## الخطوة 1️⃣: إنشاء مستودع GitHub

### أ) إذا لم يكن لديك حساب GitHub:
1. اذهب إلى [github.com](https://github.com)
2. اضغط **Sign Up**
3. أكمل التسجيل

### ب) إنشاء مستودع جديد:
1. اذهب إلى [github.com/new](https://github.com/new)
2. ملأ التفاصيل:
   - **Repository name:** `palestine-id-apk`
   - **Description:** Palestine ID - APK Builder
   - **Public** أو **Private** (اختياري)
3. اضغط **Create repository**

---

## الخطوة 2️⃣: رفع المشروع على GitHub

### من سطر الأوامر:

```bash
# الذهاب إلى مجلد المشروع
cd apk-final

# تهيئة Git
git init
git add .
git commit -m "🚀 Initial commit: Palestine ID APK project"

# إضافة الـ remote (استبدل USERNAME و REPO)
git remote add origin https://github.com/USERNAME/palestine-id-apk.git

# دفع الملفات
git branch -M main
git push -u origin main
```

### أو استخدم GitHub Desktop:
1. حمّل [GitHub Desktop](https://desktop.github.com/)
2. اضغط **File → Clone Repository**
3. ابحث عن المستودع الجديد
4. أكمل العملية

---

## الخطوة 3️⃣: تفعيل GitHub Actions

✅ **GitHub Actions مفعل افتراضياً!**

ملف الـ Actions موجود في: `.github/workflows/build-apk.yml`

### التحقق من التفعيل:

1. اذهب إلى مستودعك على GitHub
2. اضغط على تبويب **Actions**
3. يجب أن ترى **"Build APK Automatically"**

---

## الخطوة 4️⃣: كيفية البناء التلقائي

### الطريقة 1️⃣: عند كل دفع (Push)

```bash
# قم بالتعديل على الملفات
nano www/index.html

# حفظ التغييرات
git add .
git commit -m "✨ Update app design"
git push
```

**تلقائياً** سيبدأ البناء! ✅

### الطريقة 2️⃣: دفع Tags (للإصدارات)

```bash
# إنشاء إصدار جديد
git tag -a v1.0.0 -m "Release version 1.0.0"
git push origin v1.0.0
```

**سيتم:**
- بناء APK تلقائياً ✅
- إنشاء Release على GitHub ✅
- رفع APK إلى الـ Release ✅

### الطريقة 3️⃣: تشغيل يدوي

1. اذهب إلى **Actions**
2. اختر **"Build APK Automatically"**
3. اضغط **"Run workflow"**
4. اختر الـ Branch
5. اضغط **"Run workflow"**

---

## الخطوة 5️⃣: تحميل ملف APK

### من الـ Actions:

1. اذهب إلى **Actions**
2. اختر آخر عملية بناء
3. اضغط على **"palestine-id-apk"** تحت **Artifacts**
4. سينزل الملف تلقائياً

### من الـ Releases:

1. اذهب إلى **Releases**
2. اختر الإصدار
3. حمّل `app-release.apk`

---

## 📊 مراقبة البناء

### رؤية حالة البناء:

1. اذهب إلى **Actions**
2. اختر آخر عملية
3. شاهد التفاصيل:
   - ✅ **Completed** - نجح
   - ❌ **Failed** - فشل
   - ⏳ **In progress** - قيد التنفيذ

### رؤية الأخطاء:

إذا فشل البناء:

1. اضغط على **Run** الفاشلة
2. اضغط على **build** job
3. اقرأ الأخطاء
4. صحح المشكلة locally
5. ادفع التصحيح

---

## 🔐 إضافة Secrets (اختياري)

للبناء المتقدم، قد تحتاج secrets:

### إضافة Secret:

1. اذهب إلى **Settings → Secrets → Actions**
2. اضغط **New repository secret**
3. أضف:
   - **KEYSTORE_FILE** - ملف التوقيع
   - **KEYSTORE_PASSWORD** - الكلمة المرورية
   - **KEY_PASSWORD** - كلمة مرور المفتاح

### استخدام في Workflow:

```yaml
env:
  KEYSTORE_PASSWORD: ${{ secrets.KEYSTORE_PASSWORD }}
```

---

## 🎨 تخصيص الـ Workflow

### تغيير Branch الاستماع:

في `.github/workflows/build-apk.yml`:

```yaml
on:
  push:
    branches: [ main, develop, staging ]  # أضف branches هنا
```

### تغيير وقت البناء (جدولة):

```yaml
schedule:
  - cron: '0 2 * * *'  # كل يوم الساعة 2 صباحاً
```

### إرسال إشعارات عند النجاح/الفشل:

```yaml
- name: Send notification
  if: always()
  run: |
    echo "Build ${{ job.status }}"
    # أرسل إلى Slack, Discord, إلخ
```

---

## 📝 نصائح GitHub

### 1. استخدم Branch مختلفة:

```bash
# Branch للتطوير
git checkout -b develop
git push origin develop

# Branch للاختبار
git checkout -b testing
git push origin testing
```

### 2. Pull Requests:

```bash
# إنشاء PR من develop إلى main
git push origin develop

# ثم افتح PR على GitHub UI
```

### 3. Release Notes:

```bash
# عند إنشاء release، أضف وصف التغييرات
# GitHub → Releases → Draft new release
```

---

## 🚀 سير العمل الموصى به

```
1. تطوير محلي
   ↓
2. Push إلى develop
   ↓
3. GitHub Actions تختبر البناء
   ↓
4. إذا نجح، اجمع مع main
   ↓
5. أنشئ Release/Tag
   ↓
6. حمّل APK من Release
   ↓
7. وزّع على المستخدمين
```

---

## ⚠️ مشاكل شائعة

### ❌ "Build failed in GitHub Actions"

**الحل:**
1. تحقق من الأخطاء في logs
2. اختبر محلياً أولاً
3. تأكد من صحة `build-apk.yml`

### ❌ "APK file not found"

**الحل:**
- تأكد من صحة مسار البناء
- فعّل الـ artifacts

### ❌ "Permission denied"

**الحل:**
```bash
chmod +x build-apk.sh
git add build-apk.sh
git commit -m "Fix permissions"
git push
```

---

## 📚 موارد إضافية

- [GitHub Actions Documentation](https://docs.github.com/en/actions)
- [Cordova CI/CD Guide](https://cordova.apache.org/)
- [Android Build Guide](https://developer.android.com/build)

---

## ✅ تم الإعداد!

الآن لديك:
- ✅ مستودع GitHub
- ✅ Workflow تلقائي للبناء
- ✅ نسخة احتياطية للملفات
- ✅ Release Management

🎉 **استمتع بالبناء التلقائي!**

