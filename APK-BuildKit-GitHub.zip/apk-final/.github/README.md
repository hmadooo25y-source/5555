# 🤖 GitHub Actions Workflow

## البناء التلقائي للـ APK

هذا الملف (`.github/workflows/build-apk.yml`) يقوم بـ:

✅ بناء APK تلقائياً عند كل Push  
✅ إنشاء Releases  
✅ حفظ Artifacts للتحميل  
✅ دعم Tags للإصدارات  

---

## متى يتم البناء؟

1. **عند Push إلى main/master/develop**
2. **عند فتح Pull Request**
3. **عند تشغيل يدوي (workflow_dispatch)**

---

## الملفات والمجلدات المستخدمة

```
.github/
└── workflows/
    └── build-apk.yml          ← الـ Workflow الرئيسي
```

---

## الخطوات

1. 📥 تحميل الكود
2. 📦 تثبيت Node.js
3. ☕ تثبيت Java
4. 🤖 تثبيت Android SDK
5. 📚 تثبيت المكتبات
6. 🏗️ بناء المشروع
7. 🔨 بناء APK
8. 📤 رفع كـ Artifact
9. 📝 إنشاء Release (للـ tags)

---

## المدخلات (Inputs)

تلقائي - لا توجد مدخلات يدوية

---

## المخرجات (Outputs)

- 📱 **Artifact:** `palestine-id-apk`
- 📦 **Release Asset:** ملف APK على GitHub Releases

---

## التخصيص

لتغيير الـ Workflow، عدّل `build-apk.yml`:

```yaml
# تغيير إصدار Android
api-levels: 31

# تغيير الـ branches
branches: [ main, develop ]

# تغيير Package name
package: com.example.palestineidentity
```

---

## المتطلبات

✅ Node.js 18  
✅ Java 11  
✅ Android API 31  

---

للمزيد من المساعدة، راجع:
- [GITHUB_SETUP.md](../GITHUB_SETUP.md)
- [GITHUB_QUICK_GUIDE.md](../GITHUB_QUICK_GUIDE.md)

