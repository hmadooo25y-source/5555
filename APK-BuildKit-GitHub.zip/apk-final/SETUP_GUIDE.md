# 🚀 دليل تحويل تطبيق الويب إلى APK

## المتطلبات
- **Node.js** (النسخة 14 أو أحدث)
- **Java JDK** (النسخة 11 أو أحدث)
- **Android SDK** أو **Android Studio**
- **Git**

---

## الطريقة 1️⃣ : استخدام Apache Cordova (موصى بها)

### الخطوة 1: تثبيت Cordova
```bash
npm install -g cordova
```

### الخطوة 2: إنشاء مشروع جديد
```bash
cordova create my-app com.example.palestineidentity "Palestine ID"
cd my-app
```

### الخطوة 3: إضافة منصة أندرويد
```bash
cordova platform add android
```

### الخطوة 4: نسخ ملفات التطبيق
```bash
# انسخ ملف index.html إلى www/
cp /path/to/index.html www/index.html
```

### الخطوة 5: بناء APK
```bash
cordova build android --release
```

### الناتج
ستجد ملف APK هنا:
```
my-app/platforms/android/app/build/outputs/apk/release/app-release-unsigned.apk
```

---

## الطريقة 2️⃣ : استخدام Capacitor (الأحدث)

### الخطوة 1: إنشاء مشروع
```bash
npm init -y
npm install @capacitor/core @capacitor/cli
npx cap init
```

### الخطوة 2: إضافة منصة أندرويد
```bash
npm install @capacitor/android
npx cap add android
```

### الخطوة 3: نسخ الملفات
```bash
mkdir -p www
cp /path/to/index.html www/index.html
```

### الخطوة 4: المزامنة والبناء
```bash
npx cap sync
npx cap open android
```

ثم في Android Studio:
- Build → Build Bundle(s) / APK(s) → Build APK(s)

---

## الطريقة 3️⃣ : استخدام Android Studio مباشرة

### الخطوة 1: إنشاء مشروع Android جديد
- فتح Android Studio
- New Project → Empty Activity

### الخطوة 2: إضافة WebView
في `activity_main.xml`:
```xml
<WebView
    android:id="@+id/webview"
    android:layout_width="match_parent"
    android:layout_height="match_parent" />
```

### الخطوة 3: تحميل ملف HTML
في `MainActivity.java`:
```java
WebView webView = findViewById(R.id.webview);
webView.loadUrl("file:///android_asset/www/index.html");
```

### الخطوة 4: بناء APK
- Build → Build Bundle(s) / APK(s) → Build APK(s)

---

## الطريقة 4️⃣ : استخدام أداة أونلاين (PWA2APK)

1. اذهب إلى: https://www.pwabuilder.com/
2. ضع رابط الويب أو ارفع الملفات
3. حمل APK من الموقع

---

## 🔧 إعدادات مهمة

### إذا كنت تريد App Icon مخصص
في `cordova/config.xml`:
```xml
<platform name="android">
  <icon src="res/android/icon.png" density="mdpi" />
  <icon src="res/android/icon-hdpi.png" density="hdpi" />
</platform>
```

### اسم التطبيق والـ Bundle ID
```xml
<widget id="com.example.palestineidentity" version="1.0.0" xmlns="http://www.w3.org/ns/widgets">
  <name>Palestine ID</name>
  <description>نظام الهوية الفلسطينية</description>
</widget>
```

---

## 📝 ملاحظات مهمة

✅ لا تنسى إضافة صلاحيات الإنترنت في `AndroidManifest.xml`:
```xml
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.CAMERA" />
```

✅ يمكنك اختبار التطبيق على محاكي Android أو جهاز فعلي

✅ لتوقيع APK رسميًا:
```bash
jarsigner -verbose -sigalg SHA256withRSA -digestalg SHA-256 \
  -keystore my-key.keystore \
  app-release-unsigned.apk key-alias
```

---

## 📱 خطوات بسيطة للتطبيق الحالي

**الملف**: index.html (تطبيق ويب)

1. استخدم **Cordova** (الأسهل)
2. ضع الملف في مجلد `www`
3. قم بالبناء
4. ستحصل على APK

