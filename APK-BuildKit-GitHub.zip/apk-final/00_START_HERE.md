# 👈 ابدأ من هنا - START HERE

## 🎯 ماذا تريد أن تفعل؟

### ⚡ سريع وسهل (موصى به)
👉 [QUICK_START.md](QUICK_START.md) - 5 دقائق فقط

### 📚 شامل ومفصل
👉 [SETUP_GUIDE.md](SETUP_GUIDE.md) - دليل كامل مع جميع الطرق

### 📱 استخدام Android Studio (واجهة رسومية)
👉 [ANDROID_STUDIO_GUIDE.md](ANDROID_STUDIO_GUIDE.md) - خطوة بخطوة

### 📖 معلومات عامة
👉 [README.md](README.md) - معلومات شاملة

---

## 📋 محتويات المشروع

```
📦 apk-final/
│
├── 📄 00_START_HERE.md ..................... هذا الملف
├── 📄 QUICK_START.md ....................... الطريقة السريعة
├── 📄 SETUP_GUIDE.md ....................... دليل شامل
├── 📄 ANDROID_STUDIO_GUIDE.md .............. طريقة Android Studio
├── 📄 README.md ............................ معلومات عامة
│
├── 📱 www/ ................................ ملفات التطبيق
│   └── 📄 index.html ....................... تطبيق الويب الرئيسي
│
├── ⚙️ config.xml ........................... إعدادات Cordova
├── 📦 package.json ......................... معلومات npm
│
└── 🔨 build-apk.sh ......................... السكريبت التلقائي
```

---

## 🚀 خطوات البدء السريعة

### 1. تثبيت المتطلبات

```bash
# تحقق أنك تملك:
node --version    # v14+
npm --version     # v6+
java -version     # v11+
```

### 2. تشغيل البناء

**على Linux/macOS:**
```bash
chmod +x build-apk.sh
./build-apk.sh
```

**على Windows:**
```bash
# افتح PowerShell وشغّل:
./build-apk.sh
```

### 3. انتظر النتيجة

ستجد `palestine-id.apk` في مجلد `output/`

### 4. ثبّت على جهازك

```bash
# أو انسخ الملف يدويًا وثبّت من جهازك
adb install output/palestine-id.apk
```

---

## ℹ️ المعلومات المهمة

| المعلومة | القيمة |
|---------|--------|
| **اسم التطبيق** | Palestine ID |
| **Package ID** | com.example.palestineidentity |
| **النسخة** | 1.0.0 |
| **الحد الأدنى Android** | API 16 (Android 4.1) |
| **الحد الأقصى** | بدون حد أقصى |
| **اللغة** | العربية والإنجليزية |

---

## 🆘 مساعدة سريعة

### ❓ أين ملف APK؟
```
output/palestine-id.apk
```

### ❓ كيف أغيّر اسم التطبيق؟
```xml
عدّل config.xml → <name>اسمك</name>
```

### ❓ كيف أضيف أيقونة مخصصة؟
```
ضع صورة PNG في res/android/icon.png
```

### ❓ كيف أختبر التطبيق؟
```bash
# استخدم محاكي Android أو جهاز فعلي
adb install palestine-id.apk
```

### ❓ حدثت مشكلة، ماذا أفعل؟
1. اقرأ [SETUP_GUIDE.md](SETUP_GUIDE.md) قسم "مشاكل شائعة"
2. جرب حذف مجلد `platforms/` وأعد المحاولة
3. تأكد أن جميع المتطلبات مثبتة

---

## 📞 المزيد من المساعدة

| الموضوع | الملف |
|---------|------|
| 🚀 الطريقة السريعة | [QUICK_START.md](QUICK_START.md) |
| 📚 الدليل الشامل | [SETUP_GUIDE.md](SETUP_GUIDE.md) |
| 📱 Android Studio | [ANDROID_STUDIO_GUIDE.md](ANDROID_STUDIO_GUIDE.md) |
| 📖 المزيد من المعلومات | [README.md](README.md) |

---

## ✅ القائمة التحققية

- [ ] تثبيت Node.js
- [ ] تثبيت Java JDK
- [ ] تثبيت Android SDK
- [ ] نسخ المشروع
- [ ] تشغيل `build-apk.sh`
- [ ] عثرت على `palestine-id.apk`
- [ ] ثبّت على جهازك
- [ ] اختبرت التطبيق

---

## 🎉 الآن أنت جاهز!

اختر الطريقة التي تفضلها وابدأ:

**سريع؟** → [QUICK_START.md](QUICK_START.md) ⚡  
**مفصل؟** → [SETUP_GUIDE.md](SETUP_GUIDE.md) 📚  
**رسومي؟** → [ANDROID_STUDIO_GUIDE.md](ANDROID_STUDIO_GUIDE.md) 📱  

---

**آخر تحديث:** 2026-10-20  
**الحالة:** ✅ جاهز للاستخدام

