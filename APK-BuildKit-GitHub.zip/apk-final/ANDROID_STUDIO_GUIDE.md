# 📱 دليل استخدام Android Studio لإنشاء APK

إذا فضّلت استخدام واجهة رسومية بدلاً من سطر الأوامر، اتبع هذا الدليل.

---

## الخطوة 1️⃣: تحميل وتثبيت Android Studio

1. اذهب إلى [Android Developer](https://developer.android.com/studio)
2. حمّل Android Studio
3. ثبّت البرنامج على جهازك

---

## الخطوة 2️⃣: إنشاء مشروع جديد

1. افتح Android Studio
2. اختر **File → New → New Project**
3. اختر **Empty Activity**
4. املأ التفاصيل:
   - **Name:** Palestine ID
   - **Package name:** com.example.palestineidentity
   - **Minimum SDK:** API 21 (Android 5.0)
5. اضغط **Finish**

---

## الخطوة 3️⃣: إضافة WebView

### تحرير `activity_main.xml`

1. افتح `app/res/layout/activity_main.xml`
2. استبدل المحتوى بـ:

```xml
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical">

    <WebView
        android:id="@+id/webview"
        android:layout_width="match_parent"
        android:layout_height="match_parent" />

</LinearLayout>
```

---

## الخطوة 4️⃣: تحرير MainActivity

### تحرير `MainActivity.java`

1. افتح `app/java/com/example/palestineidentity/MainActivity.java`
2. استبدل المحتوى بـ:

```java
package com.example.palestineidentity;

import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebSettings;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        WebView webView = findViewById(R.id.webview);
        
        // إعدادات WebView
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);
        webSettings.setDatabaseEnabled(true);
        webSettings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        
        // تحميل ملف HTML
        webView.loadUrl("file:///android_asset/www/index.html");
    }
}
```

---

## الخطوة 5️⃣: نسخ ملفات الويب

1. في مستكشف المشروع (يسار الشاشة)
2. انقر بزر الماوس الأيمن على `app/src/main`
3. اختر **New → Directory** وسمّه `assets`
4. أنشئ مجلد `www` داخل `assets`
5. انسخ `index.html` إلى `app/src/main/assets/www/`

---

## الخطوة 6️⃣: إضافة الصلاحيات

تحرير `AndroidManifest.xml` (`app/manifests/AndroidManifest.xml`):

أضف هذه الأسطر قبل `</manifest>`:

```xml
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.CAMERA" />
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />
```

---

## الخطوة 7️⃣: البناء والاختبار

### اختبار على المحاكي

1. **Run → Run 'app'** (أو اضغط Shift + F10)
2. اختر محاكي Android أو جهازك الفعلي
3. انتظر التثبيت والتشغيل

---

## الخطوة 8️⃣: بناء APK

### للاختبار (Debug APK):

1. **Build → Build Bundle(s) / APK(s) → Build APK(s)**
2. انتظر انتهاء البناء
3. ستظهر نافذة "APK(s) generated successfully"
4. اضغط **Locate** أو ستجد الملف في:
   ```
   app/build/outputs/apk/debug/app-debug.apk
   ```

### للنشر (Release APK):

1. **Build → Generate Signed Bundle / APK**
2. اختر **APK**
3. ستحتاج إلى **keystore** (مفتاح توقيع)
   - إذا لم تملكه، اضغط **Create new...**
   - ملأ البيانات والكلمة المرورية
4. اختر **Release** كنوع البناء
5. اضغط **Finish**
6. ستجد الملف في: `app/release/app-release.apk`

---

## الخطوة 9️⃣: التثبيت على الجهاز

### طريقة 1: من Android Studio

1. **Run → Run 'app'**
2. اختر جهازك
3. سيتم التثبيت تلقائياً

### طريقة 2: استخدام ADB

```bash
# من سطر الأوامر
adb install app/build/outputs/apk/debug/app-debug.apk
```

### طريقة 3: يدويًا

1. انقل ملف APK إلى جهازك
2. فعّل: **Settings → Security → Unknown Sources**
3. افتح الملف وثبّت

---

## 🎨 تخصيصات إضافية

### تغيير اسم التطبيق

في `app/src/main/AndroidManifest.xml`:

```xml
<application
    android:label="@string/app_name"
    ...>
```

أو عدّل `app/src/main/res/values/strings.xml`:

```xml
<string name="app_name">Palestine ID</string>
```

### إضافة أيقونة مخصصة

1. ضع صورتك (512x512 PNG) في المشروع
2. استخدم **Image → Asset Studio**
3. اختر **Icon Type → Launcher Icons**
4. اتبع الخطوات

### تغيير لون شريط الحالة

في `MainActivity.java`:

```java
if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
    getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.green));
}
```

---

## ⚠️ مشاكل شائعة

### ❌ "Gradle build failed"

**الحل:**
- File → Invalidate Caches
- Restart IDE
- أعد المحاولة

### ❌ "Cannot resolve symbol WebView"

**الحل:**
```
File → Project Structure → Dependencies
أضف: androidx.webkit:webkit:1.5.0
```

### ❌ "Emulator not working"

**الحل:**
```bash
# تشغيل المحاكي من الكمبيوتر
emulator -avd emulator_name
```

### ❌ "APK installation failed"

**الحل:**
```bash
# مسح البيانات السابقة
adb uninstall com.example.palestineidentity
adb install app-debug.apk
```

---

## 📊 هيكل المشروع النهائي

```
project/
├── app/
│   ├── src/
│   │   ├── main/
│   │   │   ├── AndroidManifest.xml
│   │   │   ├── assets/
│   │   │   │   └── www/
│   │   │   │       └── index.html ✅
│   │   │   ├── java/
│   │   │   │   └── com/example/palestineidentity/
│   │   │   │       └── MainActivity.java ✅
│   │   │   └── res/
│   │   │       ├── layout/
│   │   │       │   └── activity_main.xml ✅
│   │   │       ├── values/
│   │   │       └── drawable/
│   ├── build.gradle
│   └── build/
│       └── outputs/
│           └── apk/
│               ├── debug/
│               │   └── app-debug.apk 📱
│               └── release/
│                   └── app-release.apk 📱
└── build.gradle
```

---

## 🚀 التالي

✅ اختبر التطبيق على أجهزة مختلفة  
✅ أضف ميزات مثل الإشعارات والكاميرا  
✅ انشر على [Google Play Store](https://play.google.com/console)  

---

**تم التحديث:** 2026-10-20

