# 🚀 GitHub دليل سريع

## 5 خطوات فقط!

### 1️⃣ إنشاء مستودع

```bash
# سجّل الدخول
git config --global user.name "Your Name"
git config --global user.email "you@example.com"

# تهيئة Git
git init
git add .
git commit -m "Initial commit"
```

### 2️⃣ دفع إلى GitHub

```bash
# إنشاء مستودع على github.com/new

# ربط المستودع المحلي بـ GitHub
git remote add origin https://github.com/YOUR_USERNAME/palestine-id-apk.git
git branch -M main
git push -u origin main
```

### 3️⃣ فعّل الـ Actions

✅ **مفعل افتراضياً!**

الملف موجود: `.github/workflows/build-apk.yml`

### 4️⃣ كل ما عليك فعله هو الدفع (Push)

```bash
# عدّل الملفات
nano www/index.html

# احفظ التغييرات
git add .
git commit -m "Update app"
git push
```

**✨ GitHub Actions ستبدأ البناء تلقائياً!**

### 5️⃣ حمّل APK

**من Actions:**
- اذهب إلى Actions
- اختر آخر عملية
- حمّل من Artifacts

**أو من Releases:**
- أنشئ tag: `git tag v1.0.0 && git push --tags`
- حمّل من Releases

---

## 📱 الأوامر الأساسية

```bash
# إضافة ملفات
git add .

# حفظ التغييرات
git commit -m "الرسالة"

# رفع إلى GitHub
git push

# سحب التحديثات
git pull

# رؤية الحالة
git status
```

---

## ✅ اختبر الآن!

```bash
# 1. هيّئ المشروع
cd apk-final
git init
git add .
git commit -m "🚀 Initial"

# 2. رفع إلى GitHub
git remote add origin https://github.com/YOUR_USERNAME/palestine-id-apk.git
git push -u origin main

# 3. ادخل GitHub وشاهد البناء يبدأ! 🎉
```

---

## 🎉 بسيط جداً!

الآن **كل push = بناء APK تلقائي** ✅

**استمتع!** 🚀

