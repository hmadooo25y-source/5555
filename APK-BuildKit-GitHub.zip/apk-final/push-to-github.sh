#!/bin/bash

# 🚀 سكريبت رفع المشروع إلى GitHub

echo "╔════════════════════════════════════════════════════════════════╗"
echo "║                  🚀 Push to GitHub Script                      ║"
echo "║              سكريبت رفع المشروع إلى GitHub                     ║"
echo "╚════════════════════════════════════════════════════════════════╝"

# التحقق من GitHub CLI
if ! command -v git &> /dev/null; then
    echo "❌ Git غير مثبت!"
    echo "تثبيت Git من: https://git-scm.com/"
    exit 1
fi

# قراءة البيانات من المستخدم
read -p "👤 أدخل اسم GitHub: " GITHUB_USERNAME
read -p "📁 أدخل اسم المستودع (مثال: palestine-id-apk): " REPO_NAME
read -p "📧 أدخل بريدك: " USER_EMAIL
read -p "👤 أدخل اسمك الكامل: " USER_NAME

# التحقق من البيانات
if [ -z "$GITHUB_USERNAME" ] || [ -z "$REPO_NAME" ]; then
    echo "❌ خطأ: يجب إدخال البيانات"
    exit 1
fi

echo ""
echo "📝 تكوين Git..."

# تعيين البيانات
git config --global user.email "$USER_EMAIL"
git config --global user.name "$USER_NAME"

echo "✅ تم تعيين بيانات Git"

echo ""
echo "🔧 تهيئة المستودع المحلي..."

# تهيئة Git
git init

# إضافة الملفات
git add .
git commit -m "🚀 Initial commit: Palestine ID APK project"

# تغيير اسم الـ branch إلى main
git branch -M main

# إضافة الـ remote
REMOTE_URL="https://github.com/$GITHUB_USERNAME/$REPO_NAME.git"
git remote add origin "$REMOTE_URL"

echo "✅ تم تهيئة المستودع"

echo ""
echo "════════════════════════════════════════════════════════════════"
echo "📋 الخطوة التالية:"
echo ""
echo "1️⃣ اذهب إلى: https://github.com/new"
echo "2️⃣ أنشئ مستودع باسم: $REPO_NAME"
echo "3️⃣ اختر Public أو Private"
echo "4️⃣ لا تختر أي option أخرى"
echo "5️⃣ اضغط Create repository"
echo ""
echo "6️⃣ ثم شغّل هذا الأمر:"
echo ""
echo "   git push -u origin main"
echo ""
echo "════════════════════════════════════════════════════════════════"

read -p "📌 هل أنشأت المستودع على GitHub؟ (y/n): " CONFIRM

if [ "$CONFIRM" != "y" ] && [ "$CONFIRM" != "Y" ]; then
    echo "❌ أنشئ المستودع أولاً على GitHub"
    exit 1
fi

echo ""
echo "📤 جاري رفع الملفات إلى GitHub..."

# رفع الملفات
if git push -u origin main; then
    echo ""
    echo "════════════════════════════════════════════════════════════════"
    echo "✅ تم بنجاح! 🎉"
    echo ""
    echo "📱 المشروع متوفر على:"
    echo "   $REMOTE_URL"
    echo ""
    echo "🔄 GitHub Actions ستبدأ البناء تلقائياً!"
    echo ""
    echo "📊 لمراقبة البناء:"
    echo "   $REMOTE_URL/actions"
    echo ""
    echo "✨ استمتع!"
    echo "════════════════════════════════════════════════════════════════"
else
    echo ""
    echo "❌ فشل الرفع"
    echo ""
    echo "تحقق من:"
    echo "1. اسم المستخدم والمستودع صحيح"
    echo "2. لديك صلاحيات الكتابة"
    echo "3. الاتصال بالإنترنت"
    exit 1
fi

echo ""
echo "📝 الأوامر المستقبلية:"
echo ""
echo "# لإضافة تعديل جديد:"
echo "  git add ."
echo "  git commit -m 'تصف التغيير'"
echo "  git push"
echo ""
echo "# لإنشاء إصدار:"
echo "  git tag -a v1.0.0 -m 'Release v1.0.0'"
echo "  git push --tags"
echo ""
