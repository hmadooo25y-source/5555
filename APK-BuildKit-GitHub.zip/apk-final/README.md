# 📱 Palestine ID - تطبيق الهوية الفلسطينية

## تحويل تطبيق الويب إلى APK

هذا المشروع يحتوي على جميع الملفات اللازمة لتحويل تطبيق الويب `index.html` إلى تطبيق Android APK.

---

## 🚀 الطريقة السريعة (الموصى بها)

### المتطلبات:
- ✅ **Node.js** (v14+) - [تحميل](https://nodejs.org/)
- ✅ **Java JDK** (v11+) - [تحميل](https://www.oracle.com/java/technologies/downloads/)
- ✅ **Android SDK** أو **Android Studio** - [تحميل](https://developer.android.com/studio)
- ✅ **Git** - [تحميل](https://git-scm.com/)

### الخطوات:

#### 1️⃣ تثبيت المتطلبات
```bash
# Ubuntu/Debian
sudo apt-get install nodejs npm openjdk-11-jdk-headless

# macOS
brew install node java
```

#### 2️⃣ نسخ المشروع
```bash
git clone <repository-url>
cd apk-project
```

#### 3️⃣ تشغيل السكريبت التلقائي
```bash
chmod +x build-apk.sh
./build-apk.sh
```

**النتيجة:** ستجد ملف `palestine-id.apk` في مجلد `output/`

---

## 🔧 الطريقة اليدوية باستخدام Cordova

إذا فشل السكريبت التلقائي، جرب هذه الخطوات:

```bash
# 1. تثبيت Cordova
npm install -g cordova

# 2. إنشاء مشروع
cordova create my-app com.example.palestineidentity "Palestine ID"
cd my-app

# 3. إضافة Android
cordova platform add android

# 4. نسخ الملفات
cp ../www/index.html www/
cp ../config.xml ./

# 5. بناء APK
cordova build android --release

# 6. البحث عن الملف
find . -name "*.apk" -type f
```

---

## 📱 تثبيت التطبيق على جهازك

### على جهاز فعلي:

1. **انقل ملف APK** إلى جهاز Android الخاص بك
2. **فعّل الخيار**: Settings → Security → Unknown Sources ✓
3. **افتح مدير الملفات** وانقر على ملف `palestine-id.apk`
4. **اضغط Install** وانتظر انتهاء التثبيت

### على محاكي Android:

```bash
# إذا كان لديك Android SDK مثبت:
adb install palestine-id.apk
```

---

## 🎨 تخصيص التطبيق

### تغيير اسم التطبيق:
تعديل `config.xml`:
```xml
<name>اسمك</name>
```

### إضافة أيقونة مخصصة:
ضع صورة في `res/android/icon.png` وأضف إلى `config.xml`:
```xml
<platform name="android">
    <icon src="res/android/icon.png" density="mdpi" />
</platform>
```

### تغيير الألوان والتصميم:
عدّل مباشرة `www/index.html` قبل البناء.

---

## 📋 محتوى المشروع

```
apk-project/
├── www/
│   └── index.html          # ملف التطبيق الرئيسي
├── config.xml              # إعدادات Cordova
├── build-apk.sh            # سكريبت البناء التلقائي
├── SETUP_GUIDE.md          # دليل مفصل
├── README.md               # هذا الملف
└── package.json            # معلومات npm
```

---

## ⚠️ مشاكل شائعة والحلول

### ❌ "Android SDK not found"
**الحل:**
```bash
# تعيين مسار Android SDK
export ANDROID_SDK_ROOT=/path/to/android-sdk
export PATH=$PATH:$ANDROID_SDK_ROOT/tools
```

### ❌ "Java not found"
**الحل:**
```bash
# التحقق من Java
java -version

# تثبيت Java JDK إذا لزم الأمر
# Ubuntu:
sudo apt-get install openjdk-11-jdk

# macOS:
brew install java
```

### ❌ "Gradle build failed"
**الحل:**
```bash
# مسح ملفات الذاكرة المؤقتة
rm -rf platforms/android/build
rm -rf platforms/android/.gradle

# محاولة البناء مجددًا
cordova build android --release
```

### ❌ "Cannot find module"
**الحل:**
```bash
npm install
# أو إعادة تثبيت Cordova
npm install -g cordova@latest
```

---

## 📚 موارد إضافية

- [وثائق Cordova الرسمية](https://cordova.apache.org/)
- [Android Developer Guide](https://developer.android.com/guide)
- [PWA Builder](https://www.pwabuilder.com/) - بديل أونلاين
- [Firebase Console](https://console.firebase.google.com/) - للنشر والتحليلات

---

## 🔐 توقيع APK للنشر على Google Play

```bash
# إنشاء مفتاح التوقيع
keytool -genkey -v -keystore my-release-key.jks \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -alias my-key-alias

# توقيع APK
jarsigner -verbose -sigalg SHA256withRSA \
  -digestalg SHA-256 -keystore my-release-key.jks \
  app-release-unsigned.apk my-key-alias
```

---

## 💡 نصائح

✅ جرّب التطبيق على محاكي قبل النشر على أجهزة فعلية  
✅ استخدم `adb logcat` لمراقبة الأخطاء  
✅ احتفظ بنسخة احتياطية من مفتاح التوقيع  
✅ اختبر على إصدارات Android مختلفة  

---

## 📞 الدعم

للمساعدة والأسئلة، تفضل بمراجعة:
- [Stack Overflow](https://stackoverflow.com/questions/tagged/cordova)
- [Cordova Issues](https://issues.apache.org/jira/browse/CB)
- [Reddit r/AndroidDev](https://www.reddit.com/r/androiddev/)

---

**آخر تحديث:** 2026-10-20  
**الحالة:** ✅ جاهز للاستخدام

