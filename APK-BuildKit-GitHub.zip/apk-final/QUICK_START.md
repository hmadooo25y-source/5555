# ⚡ البدء السريع - Quick Start

## 🎯 الخطوات الأساسية (5 دقائق)

### ✅ المتطلبات (تحقق منها)

```bash
node --version    # v14+
npm --version     # v6+
java -version     # v11+
```

إذا لم تكن مثبتة، اذهب إلى [SETUP_GUIDE.md](SETUP_GUIDE.md)

---

### 🚀 طريقة 1: الطريقة التلقائية (الأسهل)

```bash
# انسخ المجلد واذهب إليه
cd apk-project

# شغّل السكريبت
chmod +x build-apk.sh
./build-apk.sh
```

✅ **النتيجة:** `output/palestine-id.apk` جاهز!

---

### 🚀 طريقة 2: يدويًا باستخدام Cordova

```bash
# 1. تثبيت Cordova
npm install -g cordova

# 2. إنشاء مشروع
cordova create my-app com.example.palestineidentity "Palestine ID"
cd my-app

# 3. إضافة Android
cordova platform add android

# 4. نسخ الملفات
cp ../www/index.html www/
cp ../config.xml ./

# 5. البناء
cordova build android --release

# 6. البحث عن APK
find . -name "*.apk" -type f
```

---

### 🚀 طريقة 3: استخدام Android Studio (الأفضل للتخصيص)

[اتبع هذا الدليل](ANDROID_STUDIO_GUIDE.md)

---

## 📱 تثبيت التطبيق

### على جهازك الفعلي:

1. انسخ `palestine-id.apk` إلى جهازك
2. افتح: **Settings → Security → Unknown Sources** ✓
3. افتح ملف APK وثبّت

### على محاكي:

```bash
adb install palestine-id.apk
```

---

## 🆘 إذا حدثت مشكلة

| المشكلة | الحل |
|-------|-----|
| `command not found: cordova` | `npm install -g cordova` |
| `Android SDK not found` | [راجع SETUP_GUIDE.md](SETUP_GUIDE.md) |
| `Build failed` | حذف `platforms/android` وأعد المحاولة |
| `Java not found` | ثبّت JDK 11 أو أحدث |

---

## 📚 للمزيد من التفاصيل

- 📖 [SETUP_GUIDE.md](SETUP_GUIDE.md) - دليل شامل
- 📱 [ANDROID_STUDIO_GUIDE.md](ANDROID_STUDIO_GUIDE.md) - طريقة Android Studio
- 📖 [README.md](README.md) - معلومات عامة

---

## 💡 التعديلات السريعة

### تغيير اسم التطبيق:

عدّل `config.xml`:
```xml
<name>اسمك</name>
```

### تغيير محتوى التطبيق:

عدّل `www/index.html` مباشرة

### إعادة البناء:

```bash
./build-apk.sh
```

---

## ✅ تم!

الآن لديك:
- ✅ `palestine-id.apk` جاهز للتثبيت
- ✅ نسخة مختبرة وموثوقة
- ✅ جميع الملفات المطلوبة

🎉 **استمتع بتطبيقك!**

