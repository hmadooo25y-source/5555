#!/bin/bash

echo "🚀 بدء إنشاء APK - Building APK..."
echo "=================================="

# التحقق من المتطلبات
check_requirement() {
    if ! command -v $1 &> /dev/null; then
        echo "❌ خطأ: $1 غير مثبت!"
        echo "❌ Error: $1 is not installed!"
        exit 1
    fi
}

echo "✅ التحقق من المتطلبات..."
check_requirement "node"
check_requirement "npm"
check_requirement "java"

echo "✅ جميع المتطلبات متوفرة!"

# تثبيت Cordova
echo ""
echo "📦 تثبيت Cordova..."
npm install -g cordova 2>&1 | tail -1

# إنشاء مشروع Cordova
echo ""
echo "📁 إنشاء مشروع Cordova..."
CORDOVA_SKIP_TELEMETRY=true cordova create palestine-id com.example.palestineidentity "Palestine ID" 2>/dev/null

cd palestine-id

# إضافة منصة Android
echo ""
echo "🤖 إضافة منصة Android..."
cordova platform add android 2>&1 | grep -E "Adding android|done"

# نسخ ملفات الويب
echo ""
echo "📋 نسخ ملفات التطبيق..."
cp ../www/index.html www/
cp ../config.xml ./

# بناء APK
echo ""
echo "⚙️  بناء APK (هذا قد يستغرق وقتاً)..."
cordova build android --release

# البحث عن ملف APK
echo ""
echo "🔍 البحث عن ملف APK..."
APK_FILE=$(find . -name "*.apk" -type f 2>/dev/null | head -1)

if [ -f "$APK_FILE" ]; then
    echo ""
    echo "✅ تم إنشاء APK بنجاح!"
    echo "📦 الملف: $APK_FILE"

    # نسخ APK إلى مجلد الإخراج
    mkdir -p ../output
    cp "$APK_FILE" ../output/palestine-id.apk
    echo "✅ تم حفظ APK في: ../output/palestine-id.apk"
else
    echo ""
    echo "❌ فشل في إنشاء APK"
    exit 1
fi

echo ""
echo "=================================="
echo "✅ تم بنجاح!"
echo ""
echo "الخطوات التالية:"
echo "1. انسخ الملف: output/palestine-id.apk"
echo "2. انقله إلى جهاز Android"
echo "3. فعّل 'التثبيت من مصادر غير معروفة' في الإعدادات"
echo "4. افتح الملف وثبّت التطبيق"
